<?php
define('STATUS_SUCCESS','success');
define('STATUS_FAIL','fail');
define('STATUS_REJECT','success');
define('UPDATED_MSG_ERR','Update fails!');
define('ADDED_MSG_SUCC_COLOR','green');
define('ADDED_MSG_SUCC_CLASS','alert-success dark');
define('ADDED_MSG_FAIL_COLOR','red');
define('ADDED_MSG_FAIL_CLASS','alert-danger dark');
define('ALREADY_EXISTS_MSG','Already exists!');
define('UPDATE_MSG','Updated Successfully!');
define('PLEASE_TRY_AGAIN_MSG','Please try again.');
define('TBL_PRODUCTS','product_details');
define('TBL_USER_DETAILS','user_details');


define('TBL_CASELIFE','case_life');
define('TBL_FORM_ONE','form_one');
define('TBL_FORM_TWO','form_two');
define('TBL_FORM_THREE','form_three');
define('TBL_FORM_FOUR','form_four');
define('TBL_FORM_FIVE','form_five');
?>
