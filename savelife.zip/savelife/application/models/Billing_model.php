<?php

class Billing_model extends MY_Model
{
	function __construct()
	{
		parent::__construct();
	}

	function getListDetails()
	{
		$row = array();
		$fields = "p.*";
		$this->db->select($fields);
		$this->db->from(TBL_PRODUCTS.' p');
		$query = $this->db->get();
		if($query->num_rows() > 0){
			$row = $query->result_array();
		}
		return $row;
	}

	function downloadReport($id){
		$row = array();
		$fields = "p.*";
		$this->db->select($fields);
		$this->db->from(TBL_PRODUCTS.' p');
		$where = array("p.id_product" => $id);
		$this->db->where($where);
		$this->db->limit(1);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			$row = $query->result_array();
		}
		return $row;
	}

	function deteData($id){
		$this->db->where('id_product', $id);
		$this->db->delete(TBL_PRODUCTS);
		return array('status' => STATUS_FAIL, 'msg' => 'Deleted successfully!', 'data' => array());
	}

	function saveProduct($postVal)
	{
		$data = [
			'name'=>$postVal['name'],
			'product_id'=>$postVal['product_id'],
			'is_availabele'=>isset($postVal['is_availabele'])?$postVal['is_availabele']:'Y',
			'price'=>isset($postVal['price'])?$postVal['price']:0,
			'tax'=>isset($postVal['tax'])?$postVal['tax']:0,
			'created_on'=>date('Y-m-d H:i:s'),
		];
		if ((isset($postVal['name']) && $postVal['name'])) {
			$this->db->insert(TBL_PRODUCTS,$data);
			return array('status' => STATUS_SUCCESS, 'msg' => 'Added successfully!', 'data' => array());
		} else {
			return array('status' => STATUS_FAIL, 'msg' => 'Something went wrong', 'data' => array());
		}
	}

	function updateCase($postVal)
	{
		if ($postVal['id_product'] > 0) {
			$this->db->where("id_product", $postVal['id_product']);
			unset($postVal['submit']);
			$this->db->update(TBL_PRODUCTS, $postVal);
			return array('status' => STATUS_SUCCESS, 'msg' => 'updated successfully!', 'data' => array());
		} else {
			return array('status' => STATUS_FAIL, 'msg' => 'Some Went Wrong!', 'data' => array());
		}
	}

	function getProductDetails($postVal){
		$row = array();
		$fields = "p.*,ud.*";
		$this->db->select($fields);
		$this->db->from(TBL_PRODUCTS.' p');
		$this->db->join(TBL_USER_DETAILS.' ud','p.id_user = ud.id_user');
		$where = array("ud.email" => $postVal['email']);
		$this->db->where($where);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			$row = $query->result_array();
		}
		return $row;
	}
}
?>
