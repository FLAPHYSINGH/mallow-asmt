<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Billing extends MY_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('Billing_model');
	}
	public function index()
	{
		$data = array();
		$data['result'] = $this->Billing_model->getListDetails();
		$view   =   "billing/list_page";
		$data['pvalue'] =   ["page_title"  => "Billing Betails", "view"   =>  $view];
		$this->loadView($data);
	}


	function addnewcase()
	{
		if (isset($_POST['submit']) && ($_POST['submit'] == 'submit')) {
			$returnVal = $this->Billing_model->saveProduct($_POST);
			$this->setSuccessFailMessage($returnVal);
			header("Location:".WEB_URL);
			die();
		}
		$view = "billing/add_new_case";
		$data['pvalue'] = array("page_title" => "Add New", "page_sub_title" => "Add New", "view" => $view);
		$this->loadView($data);
	}

	function updateData()
	{
		$id = $this->uri->segment(3);
		$report = $this->Billing_model->downloadReport($id);
		$data['result'] = $report[0];
		$data['id_product'] = $id;
		if (isset($_POST['submit']) && ($_POST['submit'] == 'submit')) {
			$returnVal = $this->Billing_model->updateCase($_POST);
			$this->setSuccessFailMessage($returnVal);
			header("Location:".WEB_URL.'billing/updateData/'.$id);
			die();
		}
		$view = "billing/update_new_case";
		$data['pvalue'] = array("page_title" => "Update Case", "page_sub_title" => "Update Case", "view" => $view);
		$this->loadView($data);
	}
	function deleteData()
	{
		$id = $this->uri->segment(3);
		if ($id > 0) {
			$returnVal = $this->Billing_model->deteData($id);
			$this->setSuccessFailMessage($returnVal);
			header("Location:".WEB_URL);
			die();
		}
	}

	function downloadReport() {
		$id = $this->uri->segment(3);
		$report = $this->Billing_model->downloadReport($id);
		$csv_data[] = array('Name', 'Product Id', 'Availabe','Price','Tax');
		foreach($report as $val){
			$csv_data[] = array($val['name'],$val['product_id'],$val['is_availabele'],$val['price'], $val['tax']);
		}
		$this->generateCsvFiles('report.csv',$csv_data);
		$returnVal = array('status' => STATUS_FAIL, 'msg' => 'Downloades successfully!', 'data' => array());
		$this->setSuccessFailMessage($returnVal);
		header("Location:".WEB_URL);
		die();
	}


	function downloadAllReport() {
		$report = $this->Billing_model->getListDetails();
		$csv_data[] = array('Name', 'Product Id', 'Availabe', 'Price', 'Tax');
		foreach($report as $val){
			$csv_data[] = array($val['name'],$val['product_id'],$val['is_availabele'],$val['price'], $val['tax']);
		}
		$this->generateCsvFiles('report.csv',$csv_data);
		$returnVal = array('status' => STATUS_FAIL, 'msg' => 'Downloades successfully!', 'data' => array());
		$this->setSuccessFailMessage($returnVal);
		header("Location:".WEB_URL);
		die();
	}

	function generateBill()
	{
		$data['email'] = "";
		if(!empty($_GET['email'])){
			$data['email'] = $_GET['email'];
		}
		if (isset($_GET['submit']) && ($_GET['submit'] == 'submit')) {
			$data['result'] = $this->Billing_model->getProductDetails($_GET);
		}
		$view = "billing/generate_bill";
		$data['pvalue'] = array("page_title" => "Generate Bill", "page_sub_title" => "Generate Bill", "view" => $view);
		$this->loadView($data);
	}

	function getproductDetails()
	{
		$data = array();
		$this->load->library('Pdf');
		$data['email'] = $_POST['email'];
		$data['result'] = $this->Billing_model->getProductDetails($_POST);
		$html = $this->load->view('billing/pdf_view', $data, true);
		$filename = 'receipt_' .rand(1,100);
		$this->pdf->generate($html, $filename, '', 'A3');
	}
}
?>
