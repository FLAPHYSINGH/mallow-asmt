<div class="app-content container-fluid">
	<div class="row dashboard-row">
		<div class="col-md-12" >
			<h1 class="pl-3 pl-md-0 mb-3 py-2">
				Add New
			</h1>
			<div class="card">
				<div class="card-body card-pwd">
					<?php $this->load->view('message_view');?>
					<form method="post" action="" id="forgotPass" enctype="multipart/form-data">
						<div class="row">
							<div class="col-md-3"></div>
							<div class="col-md-6">
								<h3>Add New Product</h3>
								<hr>
								<div class="form-group">
									<label>Product Name</label>
									<input type="text" name="name" class="form-control" placeholder="Product Name">
								</div>
								<div class="form-group">
									<label>Product Id</label>
									<input type="text" name="product_id"  class="form-control" placeholder="Product Id">
								</div>
								<div class="form-group">
									<label for="exampleInputEmail1">Is Availabe</label>
									<select class="form-control selectpicker" name="is_availabele">
										<option value="Y">Yes</option>
										<option value="N">No</option>
									</select>
								</div>
								<div class="form-group">
									<label>Price</label>
									<input type="number" name="price" class="form-control" placeholder="Price">
								</div>
								<div class="form-group">
									<label>Tax</label>
									<input type="number" name="tax" class="form-control" placeholder="Tax">
								</div>
								<div class="form-group">
									<button type="submit" name="submit" value="submit" class="btn btn-info">Submit</button>
								</div>
							</div>
							<div class="col-md-3"></div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>

