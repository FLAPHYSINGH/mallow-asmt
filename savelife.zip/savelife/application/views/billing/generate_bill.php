<div class="app-content container-fluid">
	<div class="row dashboard-row">
		<div class="col-md-12" >
			<div class="card">
				<div class="card-body card-pwd">
					<?php $this->load->view('message_view');?>
					<form method="get" action="" enctype="multipart/form-data">
						<div class="row">
							<div class="col-md-3"></div>
							<div class="col-md-6">
								<h3>Billing Page</h3>
								<hr>
								<div class="form-group">
									<label>Customer Email</label>
									<input type="email" name="email" class="form-control" id="email" placeholder="Customer Email" value="<?=$email?>" required>
								</div>
								<div class="form-group">
									<button type="submit" name="submit" value="submit" class="btn btn-success">Add New</button>
								</div>
							</div>
							<div class="col-md-3"></div>
						</div>
					</form>

					<?php if(!empty($email)){?>
						<form method="post" action="getproductDetails" enctype="multipart/form-data">
							<div class="table-responsive">
								<table class="table table-line footable" cellspacing="0" data-toggle-column="last">
									<thead>
									<tr>
										<th class="text-left" style="width:30%;">Product Id</th>
										<th class="text-left" style="width:30%;">Quantity</th>
										<th class="text-left" style="width:30%;">Denomination</th>
										<th class="text-left" style="width:30%;">Count Denomination</th>
									</tr>
									</thead>
									<tbody>
									<?php
									$totatlprice = 0;
									foreach($result as $v) {
										$totatlprice = $totatlprice + $v['product_quantity']*($v['price']+$v['tax']);
										?>
											<tr>
												<td><input type="text" name="product_id[]" class="form-control" value="<?=$v['product_id']?>" readonly></td>
												<td><input type="text" name="product_quantity[]" class="form-control" value="<?=$v['product_quantity']?>" readonly></td>
												<td><input type="text" name="denomination[]" class="form-control" value="<?=$v['denomination']?>" readonly></td>
												<td><input type="text" name="qty_denomination[]" class="form-control" value="<?=$v['qty_denomination']?>" readonly></td>
											</tr>
										<?php } ?>
									<tr>
										<td class="text-left">Cash Paid By Coustomer</td>
										<td class="text-left"><b><?=$totatlprice?></b></td>
										<input type="hidden" name="email" value="<?=$email?>">
									</tr>
									</tbody>
								</table>
							</div>
							<div class="form-group">
								<a href="<?=WEB_URL?>" class="btn btn-info">Cancle</a>
								<button type="submit" name="submit" value="submit" class="btn btn-success">Generate Bill</button>
							</div>
						</form>
					<?php }?>
				</div>
			</div>
		</div>
	</div>
</div>
