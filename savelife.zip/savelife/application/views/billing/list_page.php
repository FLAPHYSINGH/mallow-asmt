<link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<!-- container -->
<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
			<div class="card overflow-hidden">
				<div class="card-body">
					<div class="">
						<div class="d-flex justify-content-between">
							<h4 class="card-title mg-b-10">Billing Betails</h4>
							<i class="mdi mdi-dots-horizontal text-gray"></i>
						</div>
					</div>
					<?php $this->load->view('message_view');?>
					<div class="table-responsive market-values">
						<div class="card-header">
							<div class="row">
								<div class="col-md-9 col-12">
									<h4 class="card-title"> Cases </h4>
								</div>
								<div class="col-1 text-right">
									<a href="<?php echo WEB_URL; ?>billing/downloadAllReport" class="btn btn-sm btn-success"><i class="ti-import"></i></a>
								</div>
								<div class="col-1 text-right">
									<a href="<?php echo WEB_URL; ?>billing/addnewcase" class="btn btn-sm btn-info"><i class="ti-plus"></i>New</a>
								</div>
							</div>
						</div>
						<table  id="datatable"  class="table table-bordered table-hover table-striped">
							<colgroup>
								<col width="15%">
								<col width="15%">
								<col width="10%">
								<col width="15%">
								<col width="15%">
								<col width="15%">
								<col width="15%">
							</colgroup>
							<thead>
							<tr>
								<th>Name</th>
								<th>Product Id</th>
								<th>Availabe</th>
								<th>Price</th>
								<th>Tax</th>
								<th>Total Price</th>
								<th>Action</th>
							</tr>
							</thead>
							<tbody>
							<?php
							if(!empty($result)){
								foreach($result as $val){?>
									<tr class="border-bottom">
										<td><?=$val['name'];?></td>
										<td class="text-right"><?=$val['product_id'];?></td>
										<td class="text-right">
											<span class="btn btn-sm <?=$val['is_availabele']=='Y'?'btn-success':'btn-danger';?>"><?=$val['is_availabele']=='Y'?'Yes':'NO';?></span>
										</td>
										<td class="text-right"><?=$val['price'];?></td>
										<td class="text-right"><?=$val['tax'];?></td>
										<td class="text-right"><?=$val['price']+$val['tax'];?></td>
										<td class="text-right">
											<a href="<?php echo WEB_URL.'billing/downloadReport/'.$val['id_product']; ?>" class="btn btn-sm btn-success"><i class="ti-import"></i></a>
											<a href="<?php echo WEB_URL.'billing/updateData/'.$val['id_product']; ?>" class="btn btn-sm btn-info"><i class="ti-pencil-alt"></i></a>
											<a href="<?php echo WEB_URL.'billing/deleteData/'.$val['id_product']; ?>" class="btn btn-sm btn-danger"><i class="ti-trash"></i></a>
										</td>
									</tr>
									<?php
								}
							} else{
								echo "No Data";
							}?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">

	$(document).ready(function(){
		var table = $('#datatable').DataTable({
			"pageLength": 10,
			"lengthChange": true,
			"processing": true,
			"bPaginate": true,
			"searching": true,
			"ordering": true
		});

	});

</script>


