
<div class="main-footer ht-40">
	<div class="container-fluid pd-t-0-f ht-100p">
		<span>Copyright © 2022 <a href="#">Abhishek Patel</a>. Designed by</span>
	</div>
</div>
<script src="<?php echo WEB_PATH; ?>assets/plugins/ionicons/ionicons.js"></script>
</body>
</html>





