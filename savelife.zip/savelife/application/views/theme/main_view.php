<?php
$this->load->view('theme/header_view');
$this->load->view($pvalue['view']);
$this->load->view('theme/footer_view');
?>
