<!-- Banner
================================================== -->
<div id="banner" style="background-image: url(images/banner-02.jpg)" class="parallax background" data-img-width="2000" data-img-height="1330" data-diff="400">
	<div class="container">
		<div class="sixteen columns">
			
			<div class="search-container">

				<!-- Form -->
				<h2> Sit back, we'll take it from here </h2>
                
				<input type="text" class="ico-01" placeholder="Search to find a service" value=""/>
                
				<input type="text" class="ico-02" placeholder="Search by Location, Community..." value=""/>
				<button><i class="fa fa-search"></i></button>
				
				<!-- Announce -->
				<div class="announce">
					Book or get free quotes for over <strong> 25 </strong>
				</div>

			</div>

		</div>
	</div>
</div>
