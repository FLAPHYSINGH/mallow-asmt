CREATE TABLE `product_details` (
  `id_product` int NOT NULL AUTO_INCREMENT,
  `id_user` int NOT NULL DEFAULT '1',
  `name` varchar(255) DEFAULT NULL COMMENT 'Name of Product',
  `product_id` varchar(255) DEFAULT NULL COMMENT 'Product Is',
  `is_availabele` enum('Y','N') NOT NULL DEFAULT 'Y' COMMENT 'Product is availabe',
  `price` double(10,2) NOT NULL DEFAULT '0.00' COMMENT 'Price Of Each product',
  `tax` double(10,2) NOT NULL DEFAULT '0.00' COMMENT 'Tax Price',
  `created_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id_product`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `product_details` (`id_product`, `id_user`, `name`, `product_id`, `is_availabele`, `price`, `tax`, `created_on`) VALUES
(1,	1,	'Shirts',	'ST123',	'Y',	10.00,	3.00,	'2022-05-02 13:40:03'),
(2,	1,	'T Shirts',	'T123',	'Y',	10.00,	1.00,	'2022-05-02 13:40:03'),
(3,	1,	'Machine',	'M123',	'Y',	10.00,	1.00,	'2022-05-02 13:40:03'),
(4,	1,	'Test',	'TEq',	'Y',	10.00,	10.00,	'2022-05-02 21:29:33')
ON DUPLICATE KEY UPDATE `id_product` = VALUES(`id_product`), `id_user` = VALUES(`id_user`), `name` = VALUES(`name`), `product_id` = VALUES(`product_id`), `is_availabele` = VALUES(`is_availabele`), `price` = VALUES(`price`), `tax` = VALUES(`tax`), `created_on` = VALUES(`created_on`);

CREATE TABLE `user_details` (
  `id_user` int NOT NULL AUTO_INCREMENT,
  `product_quantity` int NOT NULL DEFAULT '0',
  `denomination` int NOT NULL DEFAULT '10',
  `qty_denomination` int NOT NULL DEFAULT '1',
  `user_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` text,
  `phone` varchar(20) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `user_details` (`id_user`, `product_quantity`, `denomination`, `qty_denomination`, `user_name`, `email`, `address`, `phone`, `created_on`) VALUES
(1,	1,	10,	1,	'Abhishek Patel',	'abhishek212301@outlook.com',	'Testing',	'+918858030792',	NULL),
(2,	3,	500,	1,	'Abhishek',	'abhishek212301@gmail.com',	'Testing',	'+918858030792',	NULL)
ON DUPLICATE KEY UPDATE `id_user` = VALUES(`id_user`), `product_quantity` = VALUES(`product_quantity`), `denomination` = VALUES(`denomination`), `qty_denomination` = VALUES(`qty_denomination`), `user_name` = VALUES(`user_name`), `email` = VALUES(`email`), `address` = VALUES(`address`), `phone` = VALUES(`phone`), `created_on` = VALUES(`created_on`);

-- 2022-05-04 03:52:07
